# LT2212 V20 Assignment 1

# Part1
Lowercased and removed punctuation.

# Part 4
After tf-idf was performed, only the most relevant words for each class came as weighing more in the plot.

# Part Bonus
Comparing the two classification accuracies, it turns out that the data frame without tf-idf has a lower accuracy 
than the data frame with tf-idf. 

